    <!-- ======= Hero Section ======= -->
    <section >





<!-- <div class="nav-form">
         <form class="form-inline " action="<?php echo esc_url( home_url( '/' ) ); ?>">
      <input class="form-control nav-inputform" name="s" type="search" placeholder="Search" aria-label="Search">

    </form>
       </div> -->




        <div class="container" >

<!-- <?php 

$hero_group = wl_get_option('wl_hero_group');

?>

  <h1><?= $hero_group[0]['test'] ?> </h1>
  <h2><?= $hero_group[0]['test2'] ?> </h2> -->




<h3 class="text-center">خودآموزی ، کسب تجربه ، ورود به بازار کار با  باگینو</h3>
<h3 class="text-center mb-3">با کمترینــــ هزینه خودت حرفه ایــــ یاد بگیـر</h3>

<div class="mt-4">
<form  action="<?php echo esc_url( home_url( '/' ) ); ?>">
<input class="form-control nav-inputform1 " name="s" type="search" placeholder="جستجو در دوره ها" aria-label="Search">
</form>
</div>


            <!-- <div class="d-flex align-items-center">
                <i class="bx bxs-right-arrow-alt get-started-icon"></i>
                <a href="#about" class="btn-get-started scrollto">Get Started</a>
            </div> -->
        </div>
    </section>

    <!-- End Hero -->