        <!-- ======= Clients Section ======= -->
        <section id="clients" class="clients">
            <div class="container" data-aos="fade-up">

                <div class="owl-carousel clients-carousel">
                    <img src="https://s4.uupload.ir/files/photo-1542831371-29b0f74f9713_amlh.jpg" alt="">
                    <img src="https://s4.uupload.ir/files/photo-1542831371-29b0f74f9713_amlh.jpg" alt="">
                    <img src="https://s4.uupload.ir/files/photo-1542831371-29b0f74f9713_amlh.jpg" alt="">
                    <img src="https://s4.uupload.ir/files/photo-1542831371-29b0f74f9713_amlh.jpg" alt="">
                    <img src="https://s4.uupload.ir/files/photo-1542831371-29b0f74f9713_amlh.jpg" alt="">
                    <img src="https://s4.uupload.ir/files/photo-1542831371-29b0f74f9713_amlh.jpg" alt="">
                    <img src="https://s4.uupload.ir/files/photo-1542831371-29b0f74f9713_amlh.jpg" alt="">
                </div>

            </div>
        </section>
        <!-- End Clients Section -->
