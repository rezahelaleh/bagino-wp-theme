        <!-- ======= epic Section ======= -->
        <section id="team" class=" epic ">
            <div class="container" data-aos="fade-up">

                <div class="section-eren">
                    <h2>تیم ما</h2><br>
                    <!-- <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi
                        quidem hic quas.</p> -->
                </div>

                <div class="row">

                    <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
                        <div class="liquid d-flex align-items-start">
                            <div class="pic"><img src="https://s4.uupload.ir/files/e779218c690eb392da1441789b4ce9fd_87y.jpg" class="img-fluid" alt=""></div>
                            <div class="liquid-info">
                                <h4>arash pourkhosro</h4>
                                <span>Chief Executive Officer</span>
                                <p>Explicabo voluptatem mollitia et repellat qui dolorum quasi</p>
                                <p>Explicabo voluptatem mollitia et repellat qui dolorum quasi</p>
                                <a href="team.html" class="btn-y btn btn-block ">more...</a>

                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mt-4 mt-lg-0" data-aos="fade-up" data-aos-delay="200">
                        <div class="liquid d-flex align-items-start">
                            <div class="pic"><img src="https://s4.uupload.ir/files/e779218c690eb392da1441789b4ce9fd_87y.jpg" class="img-fluid" alt=""></div>
                            <div class="liquid-info">
                                <h4>reza marhounian nezhad</h4>
                                <span>Product Manager</span>
                                <p>Aut maiores voluptates amet et quis praesentium qui senda para</p>
                                <p>Aut maiores voluptates amet et quis praesentium qui senda para</p>
                                <a href="team.html" class="btn-y btn btn-block ">more...</a>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="300">
                        <div class="liquid d-flex align-items-start">
                            <div class="pic"><img src="https://s4.uupload.ir/files/e779218c690eb392da1441789b4ce9fd_87y.jpg" class="img-fluid" alt=""></div>
                            <div class="liquid-info">
                                <h4>nilofar yousef zade</h4>
                                <span>CTO</span>
                                <p>Quisquam facilis cum velit laborum corrupti fuga rerum quia</p>
                                <p>Quisquam facilis cum velit laborum corrupti fuga rerum quia</p>
                                <a href="team.html" class="btn-y btn btn-block ">more...</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mt-4" data-aos="fade-up" data-aos-delay="400">
                        <div class="liquid d-flex align-items-start">
                            <div class="pic"><img src="https://s4.uupload.ir/files/e779218c690eb392da1441789b4ce9fd_87y.jpg" class="img-fluid" alt=""></div>
                            <div class="liquid-info">
                                <h4>farhad ali zade</h4>
                                <span>Accountant</span>
                                <p>Dolorum tempora officiis odit laborum officiis et et accusamus</p>
                                <p>Dolorum tempora officiis odit laborum officiis et et accusamus</p>
                                <a href="team.html" class="btn-y btn btn-block ">more...</a>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </section>
        <!-- End epic Section -->
