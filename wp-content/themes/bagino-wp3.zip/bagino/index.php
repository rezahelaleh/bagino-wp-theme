<?PHP 
get_header() ;

 get_template_part('templates/hero');
 get_template_part('templates/whyus');
 get_template_part('templates/opal');
 get_template_part('templates/about');
 get_template_part('templates/client');
 get_template_part('templates/value');
 get_template_part('templates/feature');
 get_template_part('templates/testimentional');
 get_template_part('templates/team');
//  get_template_part('templates/faq');
 get_template_part('templates/contact');
 get_footer();

 ?>

