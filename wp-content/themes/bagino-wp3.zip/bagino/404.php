<?php get_header();?>


<!-- first -->
<!-- <div class="main-glitch">

<div title="404" class="notfound">404</div>
</div> -->

<!-- second -->


<div class="main-glitch2">


<div class="error">404</div>
<br /><br />
<span class="info">صفحه یافت نشد</span>
<img src="http://images2.layoutsparks.com/1/160030/too-much-tv-static.gif" class="static" />


</div>


<!-- third -->

<!-- <div class="main-glitch3">
<div title="404" class="notfound2" >404</div>
</div> -->

