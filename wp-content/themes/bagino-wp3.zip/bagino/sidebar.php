<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">

    <?php
    if(is_active_sidebar('single-sidebar')){
        dynamic_sidebar('single-sidebar');
    }
    ?>

</div>