<div class="wrap wps-wrap<?php echo(isset($class) ? ' ' . $class : ''); ?>">
<?php require_once WP_STATISTICS_DIR . "/includes/admin/templates/header.php";  ?>
