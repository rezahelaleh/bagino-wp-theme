<?php require_once WP_STATISTICS_DIR . "/includes/admin/templates/header.php";  ?>
<div class="wps-wrap__main">
<div class="wrap wps-wrap">
    <?php _e('Extensions for WP-Statistics', 'wp-statistics'); ?>
    <p>
    <p><?php _e('These extensions add functionality to your WP-Statistics.', 'wp-statistics'); ?></p><br/></p>
    <?php include(WP_STATISTICS_DIR . "includes/admin/templates/add-ons.php"); ?>
</div>
</div>
